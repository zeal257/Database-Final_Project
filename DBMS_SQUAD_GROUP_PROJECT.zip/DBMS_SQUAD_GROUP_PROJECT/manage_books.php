<?php



include 'db_connect.php';


function sanitize($data) {
    global $conn; 
    return mysqli_real_escape_string($conn, htmlspecialchars(strip_tags($data)));
}


$result = mysqli_query($conn, "SELECT * FROM `DataSoftquad_ourbookstore`.`Books`");
$books = mysqli_fetch_all($result, MYSQLI_ASSOC);


$authors_query = mysqli_query($conn, "SELECT * FROM `DataSoftquad_ourbookstore`.`Author`");
$authors = [];
while ($row = mysqli_fetch_assoc($authors_query)) {
    $authors[$row['Author_ID']] = $row['Name'];
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_book'])) {

    $isbn = sanitize($_POST['isbn']);
    $title = sanitize($_POST['title']);
    $year = sanitize($_POST['year']);
    $price = sanitize($_POST['price']);
    $publisher = sanitize($_POST['publisher']);
    $author = sanitize($_POST['author']);


    $sql = "INSERT INTO `DataSoftquad_ourbookstore`.`Books` (ISBN, Title, Year, Price, Publisher_Name, Author_ID) VALUES ('$isbn', '$title', '$year', '$price', '$publisher', '$author')";
    mysqli_query($conn, $sql);

    header('Location: manage_books.php');
    exit;
}

// Edit a book
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_book'])) {

    $id = sanitize($_POST['id']);
    $isbn = sanitize($_POST['isbn']);
    $title = sanitize($_POST['title']);
    $year = sanitize($_POST['year']);
    $price = sanitize($_POST['price']);
    $publisher = sanitize($_POST['publisher']);
    $author = sanitize($_POST['author']);


    $sql = "UPDATE `DataSoftquad_ourbookstore`.`Books` SET ISBN = '$isbn', Title = '$title', Year = '$year', Price = '$price', Publisher_Name = '$publisher', Author_ID = '$author' WHERE Book_Id = '$id'";
    mysqli_query($conn, $sql);


    header('Location: manage_books.php');
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_book'])) {

    $id = sanitize($_POST['id']);
    

    echo "Received book ID for deletion: $id";


    $sql = "DELETE FROM `DataSoftquad_ourbookstore`.`Books` WHERE Book_Id = '$id'";
    $result = mysqli_query($conn, $sql);
    if (!$result) {
        echo "Error deleting book: " . mysqli_error($conn);
    } else {
        echo "Book deleted successfully.";
    }


    header('Location: manage_books.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/manage_books.css">

</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="images/logo.png" alt="Logo">
            </div>
            <nav class="navigation">
            </nav>
        </div>
    </header>


    <aside class="side-panel">
        <div class="container">
            <ul>
                <li><a  href="dashboard.php">Dashboard</a></li>
                <li><a class="active" href="manage_books.php">Books</a></li>
                <li><a href="manage_customers.php">Customers</a></li>
                <li><a  href="manage_authors.php">Authors</a></li>
                <li><a href="books.php">Buy Books</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </aside>

    <main class="main-content">
        <div class="container">
            <h1>Manage Books</h1>
            <h2>Add Book</h2>
            <form action="" method="post">
                <input type="text" name="isbn" placeholder="ISBN" required>
                <input type="text" name="title" placeholder="Title" required>
                <input type="text" name="year" placeholder="Year" required>
                <input type="text" name="price" placeholder="Price" required>
                <input type="text" name="publisher" placeholder="Publisher" required>
                <select name="author" required>
                    <?php foreach ($authors as $author_id => $author_name): ?>
                        <option value="<?php echo $author_id; ?>"><?php echo $author_name; ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="add_book">Add Book</button>
            </form>


            <h2>Book List</h2>
            <table>
                <thead>
                    <tr>
                        <th>ISBN</th>
                        <th>Title</th>
                        <th>Year</th>
                        <th>Price</th>
                        <th>Publisher</th>
                        <th>Author</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($books as $book): ?>
                        <tr>
                            <td><?php echo $book['ISBN']; ?></td>
                            <td><?php echo $book['Title']; ?></td>
                            <td><?php echo $book['Year']; ?></td>
                            <td><?php echo $book['Price']; ?></td>
                            <td><?php echo $book['Publisher_Name']; ?></td>
                            <td><?php echo $authors[$book['Author_ID']]; ?></td>
                            <td>

                                <form action="" method="post" style="display: inline-block;">
                                    <input type="hidden" name="id" value="<?php echo $book['Book_Id']; ?>">
                                    <input type="text" name="isbn" value="<?php echo $book['ISBN']; ?>" required>
                                    <input type="text" name="title" value="<?php echo $book['Title']; ?>" required>
                                    <input type="text" name="year" value="<?php echo $book['Year']; ?>" required>
                                    <input type="text" name="price" value="<?php echo $book['Price']; ?>" required>
                                    <input type="text" name="publisher" value="<?php echo $book['Publisher_Name']; ?>" required>
                                    <select name="author" required>
                                        <?php foreach ($authors as $author_id => $author_name): ?>
                                            <option value="<?php echo $author_id; ?>" <?php if ($author_id == $book['Author_ID']) echo 'selected'; ?>><?php echo $author_name; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="edit_book">Edit</button>
                                </form>
                                
      
                                <form action="" method="post" style="display: inline-block;">
                                    <input type="hidden" name="id" value="<?php echo $book['Book_Id']; ?>">
                                    <button type="submit" name="delete_book">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
    <footer class="footer">
 
    </footer>

</body>
</html>
