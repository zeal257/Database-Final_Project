<?php


// Include the database connection
include 'db_connect.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_id']) && isset($_POST['quantity'])) {
    // Sanitize input data
    $book_id = $_POST['book_id'];
    $quantity = $_POST['quantity'];

    // Add a default row to the ShoppingCart table if it's empty
    $check_query = "SELECT COUNT(*) as count FROM ShoppingCart";
    $result = mysqli_query($conn, $check_query);
    $row = mysqli_fetch_assoc($result);
    if ($row['count'] == 0) {
        // If the table is empty, insert a default row
        $default_query = "INSERT INTO ShoppingCart (Customer_Id) VALUES (NULL)";
        mysqli_query($conn, $default_query);
    }

    // Fetch the Shopping_cart_id from the ShoppingCart table
    $cart_query = "SELECT Shopping_cart_id FROM ShoppingCart LIMIT 1";
    $cart_result = mysqli_query($conn, $cart_query);
    $cart_row = mysqli_fetch_assoc($cart_result);
    $shopping_cart_id = $cart_row['Shopping_cart_id'];

    // Insert the item into the shopping cart
    $insert_query = "INSERT INTO ShoppingCartItems (Shopping_cart_id, Book_Id, Quantity) VALUES ($shopping_cart_id, $book_id, $quantity)";
    mysqli_query($conn, $insert_query);

    // Redirect to the cart page
    header('Location: cart.php');
    exit;
} else {
    // Invalid request, redirect to books page
    header('Location: books.php');
    exit;
}
?>
