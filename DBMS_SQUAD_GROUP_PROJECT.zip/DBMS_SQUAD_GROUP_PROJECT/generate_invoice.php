<?php

require('fpdf186/fpdf.php');
require 'db_connect.php';

$invoice_number = 'DSS001';

// Fetch customer details
$customer_query = "SELECT * FROM Customer WHERE Customer_Id = (SELECT Customer_Id FROM ShoppingCart WHERE Shopping_cart_id = 1)";
$customer_result = mysqli_query($conn, $customer_query);
$customer_row = mysqli_fetch_assoc($customer_result);

// Fetch shopping cart items
$cart_query = "SELECT ShoppingCartItems.*, Books.Title, Books.Price FROM ShoppingCartItems 
                JOIN Books ON ShoppingCartItems.Book_Id = Books.Book_Id";
$cart_result = mysqli_query($conn, $cart_query);

// Calculate total price
$total_price_query = "SELECT SUM(Books.Price * ShoppingCartItems.Quantity) AS TotalPrice
                      FROM ShoppingCartItems
                      JOIN Books ON ShoppingCartItems.Book_Id = Books.Book_Id";
$total_price_result = mysqli_query($conn, $total_price_query);
$total_price_row = mysqli_fetch_assoc($total_price_result);
$total_price = $total_price_row['TotalPrice'];

// Tax rate
$tax_rate = 0.05; // 5%

// Total amount including tax
$total_amount = $total_price * (1 + $tax_rate);

// Create PDF
class PDF extends FPDF
{
    function Header()
    {
        // Dark background
        $this->SetFillColor(40, 40, 40);
        $this->Rect(0, 0, 210, 297, 'F');

        // Logo in header
        $this->Image('images/logo.png', 10, 10, 40);

        // Invoice details at the right side
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(255);
        $this->Cell(0, 10, 'Invoice #' . $GLOBALS['invoice_number'], 0, 0, 'R');
        $this->Ln(5);
        $this->Cell(0, 10, 'Issue Date: ' . date('Y-m-d'), 0, 0, 'R');
        $this->Ln(15);
    }

    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Dark background
        $this->SetFillColor(40, 40, 40);
        $this->Rect(0, 279, 210, 18, 'F');
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Text color
        $this->SetTextColor(255);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Customer Details
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(255);
$pdf->Cell(60, 10, 'Customer Details:', 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(255);
$pdf->Cell(60, 10, 'Name: ' . $customer_row['Name'], 0, 1);
$pdf->Cell(60, 10, 'Address: ' . $customer_row['Address'], 0, 1);
$pdf->Cell(60, 10, 'Phone: ' . $customer_row['Phone'], 0, 1);
$pdf->Ln(5);

// Items
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(40, 40, 40);
$pdf->SetTextColor(255);
$pdf->Cell(190, 10, 'Items:', 0, 1, '', true);
$pdf->SetFont('Arial', '', 12);
$pdf->SetFillColor(60, 60, 60);
$pdf->SetTextColor(255);
$pdf->Cell(100, 10, 'Title', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Price', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Quantity', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Total', 1, 1, 'C', true);
while ($row = mysqli_fetch_assoc($cart_result)) {
    $pdf->Cell(100, 10, $row['Title'], 1, 0, '', true);
    $pdf->Cell(30, 10, $row['Price'], 1, 0, 'C', true);
    $pdf->Cell(30, 10, $row['Quantity'], 1, 0, 'C', true);
    $pdf->Cell(30, 10, $row['Price'] * $row['Quantity'], 1, 1, 'C', true);
}

// Subtotal
$pdf->SetFillColor(40, 40, 40);
$pdf->SetTextColor(255);
$pdf->Cell(160, 10, 'Subtotal:', 1, 0, 'R', true);
$pdf->Cell(30, 10, '$' . number_format($total_price, 2), 1, 1, 'C', true);

// Tax
$pdf->SetTextColor(255);
$pdf->Cell(160, 10, 'Tax (5%):', 1, 0, 'R');
$pdf->Cell(30, 10, '$' . number_format($total_price * $tax_rate, 2), 1, 1, 'C');

// Total Amount
$pdf->SetFillColor(40, 40, 40);
$pdf->SetTextColor(255);
$pdf->Cell(160, 10, 'Total Amount:', 1, 0, 'R', true);
$pdf->Cell(30, 10, '$' . number_format($total_amount, 2), 1, 1, 'C', true);

// Output PDF
$pdf->Output();

// Delete entries from shopping cart and shopping cart items
$delete_cart_query = "DELETE FROM ShoppingCart WHERE Shopping_cart_id = 1";
mysqli_query($conn, $delete_cart_query);

$delete_items_query = "DELETE FROM ShoppingCartItems WHERE Shopping_cart_id = 1";
mysqli_query($conn, $delete_items_query);
?>
