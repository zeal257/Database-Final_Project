<?php



include 'db_connect.php';

// Fetch customer details
$customer_id = null;
$customer_row = null;

// Check if customer is linked to cart
$cart_customer_query = "SELECT Customer_Id FROM ShoppingCart WHERE Shopping_cart_id = 1"; 
$cart_customer_result = mysqli_query($conn, $cart_customer_query);

if ($cart_customer_result) {
    $cart_customer_row = mysqli_fetch_assoc($cart_customer_result);
    if ($cart_customer_row) {
        $customer_id = $cart_customer_row['Customer_Id'];
        $customer_query = "SELECT * FROM Customer WHERE Customer_Id = $customer_id";
        $customer_result = mysqli_query($conn, $customer_query);

        if ($customer_result) {
            $customer_row = mysqli_fetch_assoc($customer_result);
            if (!$customer_row) {
                echo "No customer found with ID: $customer_id";
            }
        } else {
            echo "Error fetching customer details: " . mysqli_error($conn);
        }
    } else {
        echo "No customer linked to cart.";
    }
} else {
    echo "Error fetching cart customer: " . mysqli_error($conn);
}


// Check if customer is linked to cart
$cart_customer_query = "SELECT Customer_Id FROM ShoppingCart WHERE Shopping_cart_id = 1"; 
$cart_customer_result = mysqli_query($conn, $cart_customer_query);

if ($cart_customer_result) {
    $cart_customer_row = mysqli_fetch_assoc($cart_customer_result);
    if ($cart_customer_row) {
        $customer_id = $cart_customer_row['Customer_Id'];
        $customer_query = "SELECT * FROM Customer WHERE Customer_Id = $customer_id";
        $customer_result = mysqli_query($conn, $customer_query);

        if ($customer_result) {
            $customer_row = mysqli_fetch_assoc($customer_result);
        } else {

            echo "Error fetching customer details: " . mysqli_error($conn);
        }
    } else {

        echo "No customer linked to cart.";
    }
} else {

    echo "Error fetching cart customer: " . mysqli_error($conn);
}

// Fetch shopping cart items
$cart_query = "SELECT ShoppingCartItems.*, Books.Title, Books.Price FROM ShoppingCartItems 
                JOIN Books ON ShoppingCartItems.Book_Id = Books.Book_Id";
$cart_result = mysqli_query($conn, $cart_query);

// Check if query execution was successful
if (!$cart_result) {

    echo "Error fetching cart items: " . mysqli_error($conn);
}

// Calculate total price
$total_price_query = "SELECT SUM(Books.Price * ShoppingCartItems.Quantity) AS TotalPrice
                      FROM ShoppingCartItems
                      JOIN Books ON ShoppingCartItems.Book_Id = Books.Book_Id";
$total_price_result = mysqli_query($conn, $total_price_query);

// Check if query execution was successful
if ($total_price_result) {

    $total_price_row = mysqli_fetch_assoc($total_price_result);

    if ($total_price_row) {
        $total_price = $total_price_row['TotalPrice'];
    } else {

        echo "Error calculating total price: No result.";
    }
} else {

    echo "Error calculating total price: " . mysqli_error($conn);
}

// Place order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
  
    header('Location: order_success.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/manage_books.css">
    <style>
       
        .total-price {
            font-weight: bold;
            font-size: 1.2em;
            color: #4CAF50;
            margin-bottom: 10px;
        }
        .place-order-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 10px;
        }
        .place-order-btn:hover {
            background-color: #45a049;
        }
        .back-to-cart-link {
            display: inline-block;
            text-decoration: none;
            color: #4CAF50;
            border: 1px solid #4CAF50;
            padding: 8px 15px;
            border-radius: 5px;
            margin-right: 10px;
        }
        .back-to-cart-link:hover {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="images/logo.png" alt="Logo">
            </div>
            <nav class="navigation">
            </nav>
        </div>
    </header>

    <aside class="side-panel">
        <div class="container">
            <ul>
                <li><a  href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_books.php">Books</a></li>
                <li><a href="manage_customers.php">Customers</a></li>
                <li><a href="manage_authors.php">Authors</a></li>
                <li><a  href="books.php">Buy Books</a></li>
                <li><a  href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </aside>

    <main class="main-content">
    <div class="container">
        <h1>Checkout</h1>
        <?php if ($customer_row) : ?>
        <h2>Customer Details</h2>
        <p>Name: <?= $customer_row['Name'] ?></p>
        <p>Address: <?= $customer_row['Address'] ?></p>
        <p>Phone: <?= $customer_row['Phone'] ?></p>
        <?php endif; ?>

        <h2>Cart Items</h2>
        <table border="1">
            <tr>
                <th>Title</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($cart_result)) : ?>
            <tr>
                <td><?= $row['Title'] ?></td>
                <td><?= $row['Price'] ?></td>
                <td><?= $row['Quantity'] ?></td>
                <td><?= $row['Price'] * $row['Quantity'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <p class="total-price">Total Price: <?= isset($total_price) ? $total_price : 0 ?></p>

        <form action="checkout.php" method="post" style="display: flex; justify-content: center;">
            <input type="submit" class="place-order-btn" name="place_order" value="Place Order">
            
        </form>

        <a href="cart.php" style="display: inline-block; padding: 10px 20px; margin-top: 20px; text-decoration: none; color: #fff; background-color: #37429c; border-radius: 5px;">Back to Cart</a>
            </div>
    </main>

    <footer class="footer">
 
    </footer>
</body>
</html>
