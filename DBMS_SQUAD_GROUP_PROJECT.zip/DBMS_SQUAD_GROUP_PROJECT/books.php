<?php


// Include the database connection
include 'db_connect.php';

// Fetch books from the database
$result = mysqli_query($conn, "SELECT * FROM `DataSoftquad_ourbookstore`.`Books`");
$books = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DataSoftquad Bookstore</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/manage_books.css">
    
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="images/logo.png" alt="Logo">
            </div>
            <nav class="navigation">
            </nav>
        </div>
    </header>

    <aside class="side-panel">
        <div class="container">
            <ul>
                <li><a  href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_books.php">Books</a></li>
                <li><a href="manage_customers.php">Customers</a></li>
                <li><a href="manage_authors.php">Authors</a></li>
                <li><a class="active" href="books.php">Buy Books</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </aside>

    <main class="main-content">
    <h1>Select Books to buy</h1>
        <div class="booksection">
        <?php
        if ($books) {
            foreach ($books as $book) {
                echo "<div>";
                echo "<h2>{$book['Title']}</h2>";
                echo "<p>Price: {$book['Price']}</p>";
                echo "<form action='add_to_cart.php' method='post'>";
                echo "<input type='hidden' name='book_id' value='{$book['Book_Id']}'>";
                echo "<input type='number' name='quantity' value='1' min='1'>";
                echo "<button type='submit'>Add to Cart</button>";
                echo "</form>";
                echo "</div>";
            }
        } else {
            echo "<p>No books found.</p>";
        }
        ?>
        </div>
    </main>
    <footer class="footer">
 
    </footer>
</body>
</html>
