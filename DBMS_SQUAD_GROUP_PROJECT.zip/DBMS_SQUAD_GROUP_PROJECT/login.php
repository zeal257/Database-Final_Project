<?php



session_start();

// Hardcoded admin credentials
$admin_username = "admin";
$admin_password = "admin";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Check if username and password match the hardcoded credentials
    if ($username === $admin_username && $password === $admin_password) {
        // Set session variable to indicate user is logged in
        $_SESSION["loggedin"] = true;

        // Redirect to dashboard page
        header("Location: dashboard.php");
        exit;
    } else {
        // Redirect back to login page with error message
        header("Location: login.php?error=invalid");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header class="header">
            <img src="images/logo.png" alt="Logo" class="logo">
    </header>
    
    <div class="wrapper">
        <div class="login-box">
            <h2>Admin Login</h2>
            <form action="login.php" method="POST">
                <div class="form-group">
                    <input type="text" id="username" name="username" placeholder="Username" required>
                </div>
                <div class="form-group">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    </div>
    
    <footer class="footer">
 
    </footer>
</body>
</html>
