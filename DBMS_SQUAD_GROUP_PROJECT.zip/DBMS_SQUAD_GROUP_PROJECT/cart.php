<?php



// Include the database connection
include 'db_connect.php';

// Fetch customers
$customers_query = "SELECT * FROM Customer";
$customers_result = mysqli_query($conn, $customers_query);

// Fetch shopping cart items
$cart_query = "SELECT ShoppingCartItems.*, Books.Title, Books.Price FROM ShoppingCartItems 
                JOIN Books ON ShoppingCartItems.Book_Id = Books.Book_Id";
$cart_result = mysqli_query($conn, $cart_query);

// Calculate total price
$total_price_query = "SELECT SUM(Books.Price * ShoppingCartItems.Quantity) AS TotalPrice
                      FROM ShoppingCartItems
                      JOIN Books ON ShoppingCartItems.Book_Id = Books.Book_Id";
$total_price_result = mysqli_query($conn, $total_price_query);
$total_price_row = mysqli_fetch_assoc($total_price_result);
$total_price = $total_price_row['TotalPrice'];

// Update quantity if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_id']) && isset($_POST['quantity'])) {
    $item_id = $_POST['item_id'];
    $quantity = $_POST['quantity'];

    if ($quantity == 0) {
        // Remove item if quantity is 0
        $delete_query = "DELETE FROM ShoppingCartItems WHERE Item_id = $item_id";
        mysqli_query($conn, $delete_query);
    } else {
        // Update quantity
        $update_query = "UPDATE ShoppingCartItems SET Quantity = $quantity WHERE Item_id = $item_id";
        mysqli_query($conn, $update_query);
    }

    // Redirect back to cart page to update the display
    header('Location: cart.php');
    exit;
}

// Link customer to cart if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['customer_id'])) {
    $customer_id = $_POST['customer_id'];

    // Update the shopping cart with the selected customer ID
    $update_cart_query = "UPDATE ShoppingCart SET Customer_Id = $customer_id WHERE Shopping_cart_id = 1"; 
    mysqli_query($conn, $update_cart_query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/manage_books.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="images/logo.png" alt="Logo">
            </div>
            <nav class="navigation">
            </nav>
        </div>
    </header>

    <aside class="side-panel">
        <div class="container">
            <ul>
                <li><a  href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_books.php">Books</a></li>
                <li><a href="manage_customers.php">Customers</a></li>
                <li><a href="manage_authors.php">Authors</a></li>
                <li><a  href="books.php">Buy Books</a></li>
                <li><a class="active" href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </aside>

    <main class="main-content">
    <div class="container">
        <h1>Shopping Cart</h1>
        <h2>Select Customer</h2>
        <form action="cart.php" method="post">
        <select name="customer_id">
        <?php while ($customer_row = mysqli_fetch_assoc($customers_result)) : ?>
            <option value="<?= $customer_row['Customer_Id'] ?>"><?= $customer_row['Name'] ?></option>
        <?php endwhile; ?>
        </select>
        <input type="submit" value="Link Customer to Cart">
        </form>


        <table>
            <tr>
                <th>Title</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($cart_result)) : ?>
            <tr>
                <td><?= $row['Title'] ?></td>
                <td><?= $row['Price'] ?></td>
                <td>
                    <form action="cart.php" method="post">
                        <input type="hidden" name="item_id" value="<?= $row['Item_id'] ?>">
                        <input type="number" name="quantity" value="<?= $row['Quantity'] ?>" min="0">
                        <input type="submit" value="Update">
                    </form>
                </td>
                <td><?= $row['Price'] * $row['Quantity'] ?></td>
                <td>
                    <form action="cart.php" method="post">
                        <input type="hidden" name="item_id" value="<?= $row['Item_id'] ?>">
                        <input type="hidden" name="quantity" value="0">
                        <input type="submit" value="Remove">
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>

        <p style="margin-top: 20px; font-size: 18px; font-weight: bold;">Total Price: <?= isset($total_price) ? $total_price : 0 ?></p>

        <a href="checkout.php" style="display: inline-block; padding: 10px 20px; margin-top: 20px; text-decoration: none; color: #fff; background-color: #37429c; border-radius: 5px;">Proceed to Checkout</a> 

        <a href="books.php" style="display: inline-block; padding: 10px 20px; margin-top: 20px; text-decoration: none; color: #fff; background-color: #37429c; border-radius: 5px;">Back to Books</a>
            </div>
    </main>

    <footer class="footer">
 
    </footer>
    
</body>
</html>
