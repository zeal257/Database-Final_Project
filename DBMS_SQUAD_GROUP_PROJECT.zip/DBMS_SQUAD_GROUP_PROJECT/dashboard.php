



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="images/logo.png" alt="Logo">
            </div>
            <nav class="navigation">
                
        </div>
    </header> 

    <aside class="side-panel">
        <div class="container">
            <ul>
                <li><a class="active" href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_books.php">Books</a></li>
                <li><a href="manage_customers.php">Customers</a></li>
                <li><a href="manage_authors.php">Authors</a></li>
                <li><a href="books.php">Buy Books</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </aside>

    <main class="main-content">
        <div class="container">
            <div class="dashboard">
                <h1>Welcome to the Dashboard</h1>
            </div>

            <div class="stats">
                <div class="stat">
                    <h3>Total Books</h3>
                    <p>1200</p>
                </div>
                <div class="stat">
                    <h3>Total Customers</h3>
                    <p>400</p>
                </div>
                <div class="stat">
                    <h3>Total Authors</h3>
                    <p>200</p>
                </div>
                <div class="stat">
                    <h3>Total Orders</h3>
                    <p>300</p>
                </div>
            </div>


            <h1>New Added Books</h1>
            <div class="grid-container">
  <div class="grid-item">
    <img src="images/image1.jpg" alt="Image 1">
  </div>
  <div class="grid-item">
  <img src="images/image2.jpg" alt="Image 1">
    
  </div>
  <div class="grid-item">
  <img src="images/image3.jpg" alt="Image 1">
   
  </div>
</div>

        </div>
    </main>

    <footer class="footer">
 
    </footer>
</body>
</html>
