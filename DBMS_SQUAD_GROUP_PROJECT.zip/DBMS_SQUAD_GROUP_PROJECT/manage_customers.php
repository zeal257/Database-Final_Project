<?php



include 'db_connect.php';


function sanitize($data) {
    global $conn; 
    return mysqli_real_escape_string($conn, htmlspecialchars(strip_tags($data)));
}


$result = mysqli_query($conn, "SELECT * FROM `DataSoftquad_ourbookstore`.`Customer`");
$customers = mysqli_fetch_all($result, MYSQLI_ASSOC);


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_customer'])) {

    $email = sanitize($_POST['email']);
    $name = sanitize($_POST['name']);
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);


    $sql = "INSERT INTO `DataSoftquad_ourbookstore`.`Customer` (Email, Name, Address, Phone) VALUES ('$email', '$name', '$address', '$phone')";
    mysqli_query($conn, $sql);

    header('Location: manage_customers.php');
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_customer'])) {

    $id = sanitize($_POST['id']);
    $email = sanitize($_POST['email']);
    $name = sanitize($_POST['name']);
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);


    $sql = "UPDATE `DataSoftquad_ourbookstore`.`Customer` SET Email = '$email', Name = '$name', Address = '$address', Phone = '$phone' WHERE Customer_Id = '$id'";
    mysqli_query($conn, $sql);


    header('Location: manage_customers.php');
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_customer'])) {

    $id = sanitize($_POST['id']);
    $sql = "DELETE FROM `DataSoftquad_ourbookstore`.`Customer` WHERE Customer_Id = '$id'";
    mysqli_query($conn, $sql);

    header('Location: manage_customers.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Customers</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/manage_books.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="images/logo.png" alt="Logo">
            </div>
            <nav class="navigation">
            </nav>
        </div>
    </header>

    <aside class="side-panel">
        <div class="container">
            <ul>
                <li><a  href="dashboard.php">Dashboard</a></li>
                <li><a  href="manage_books.php">Books</a></li>
                <li><a class="active" href="manage_customers.php">Customers</a></li>
                <li><a  href="manage_authors.php">Authors</a></li>
                <li><a href="books.php">Buy Books</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </aside>

    <main class="main-content">
    <div class="container">
        <h1>Manage Customers</h1>
        <h2>Add Customer</h2>
        <form action="" method="post">
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="name" placeholder="Name" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="phone" placeholder="Phone" required>
            <button type="submit" name="add_customer">Add Customer</button>
        </form>

        <h2>Customer List</h2>
        <table>
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                    <tr>
                        <td><?php echo $customer['Email']; ?></td>
                        <td><?php echo $customer['Name']; ?></td>
                        <td><?php echo $customer['Address']; ?></td>
                        <td><?php echo $customer['Phone']; ?></td>
                        <td>
                                <form action="" method="post" style="display: inline-block;">
                                <input type="hidden" name="id" value="<?php echo $customer['Customer_Id']; ?>">
                                <input type="email" name="email" value="<?php echo $customer['Email']; ?>" required>
                                <input type="text" name="name" value="<?php echo $customer['Name']; ?>" required>
                                <input type="text" name="address" value="<?php echo $customer['Address']; ?>" required>
                                <input type="text" name="phone" value="<?php echo $customer['Phone']; ?>" required>
                                <button type="submit" name="edit_customer">Edit</button>
                            </form>
                            
                            <form action="" method="post" style="display: inline-block;">
                                <input type="hidden" name="id" value="<?php echo $customer['Customer_Id']; ?>">
                                <button type="submit" name="delete_customer">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                </div>
    </main>
    <footer class="footer">
 
    </footer>
</body>
</html>
