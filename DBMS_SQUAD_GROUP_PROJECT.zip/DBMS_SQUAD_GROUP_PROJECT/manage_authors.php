<?php


// Include the database connection
include 'db_connect.php';

// Function to sanitize input data
function sanitize($data) {
    global $conn; // Use the global $conn variable
    return mysqli_real_escape_string($conn, htmlspecialchars(strip_tags($data)));
}

// Fetch authors from the database
$result = mysqli_query($conn, "SELECT * FROM `DataSoftquad_ourbookstore`.`Author`");
$authors = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Add a new author
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_author'])) {
    $name = sanitize($_POST['name']);
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);
    $url = sanitize($_POST['url']);


    $sql = "INSERT INTO `DataSoftquad_ourbookstore`.`Author` (Name, Address, Phone, URL) VALUES ('$name', '$address', '$phone', '$url')";
    mysqli_query($conn, $sql);

    // Redirect to refresh the page
    header('Location: manage_authors.php');
    exit;
}

// Edit an author
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_author'])) {

    $id = sanitize($_POST['id']);
    $name = sanitize($_POST['name']);
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);
    $url = sanitize($_POST['url']);


    $sql = "UPDATE `DataSoftquad_ourbookstore`.`Author` SET Name = '$name', Address = '$address', Phone = '$phone', URL = '$url' WHERE Author_ID = '$id'";
    mysqli_query($conn, $sql);

    // Redirect to refresh the page
    header('Location: manage_authors.php');
    exit;
}

// Delete an author
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_author'])) {

    $id = sanitize($_POST['id']);


    $sql = "DELETE FROM `DataSoftquad_ourbookstore`.`Author` WHERE Author_ID = '$id'";
    mysqli_query($conn, $sql);

    // Redirect to refresh the page
    header('Location: manage_authors.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Authors</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/manage_books.css">

</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="images/logo.png" alt="Logo">
            </div>
            <nav class="navigation">
            </nav>
        </div>
    </header>

    <aside class="side-panel">
        <div class="container">
            <ul>
                <li><a  href="dashboard.php">Dashboard</a></li>
                <li><a href="manage_books.php">Books</a></li>
                <li><a href="manage_customers.php">Customers</a></li>
                <li><a class="active" href="manage_authors.php">Authors</a></li>
                <li><a href="books.php">Buy Books</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </aside>

    <main class="main-content">
    <div class="container">
        <h1>Manage Authors</h1>
        <h2>Add Author</h2>
        <form action="" method="post">
            <input type="text" name="name" placeholder="Name" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="phone" placeholder="Phone" required>
            <input type="text" name="url" placeholder="URL" required>
            <button type="submit" name="add_author">Add Author</button>
        </form>


        <h2>Author List</h2>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($authors as $author): ?>
                    <tr>
                        <td><?php echo $author['Name']; ?></td>
                        <td><?php echo $author['Address']; ?></td>
                        <td><?php echo $author['Phone']; ?></td>
                        <td><?php echo $author['URL']; ?></td>
                        <td>

                            <form action="" method="post" style="display: inline-block;">
                                <input type="hidden" name="id" value="<?php echo $author['Author_ID']; ?>">
                                <input type="text" name="name" value="<?php echo $author['Name']; ?>" required>
                                <input type="text" name="address" value="<?php echo $author['Address']; ?>" required>
                                <input type="text" name="phone" value="<?php echo $author['Phone']; ?>" required>
                                <input type="text" name="url" value="<?php echo $author['URL']; ?>" required>
                                <button type="submit" name="edit_author">Edit</button>
                            </form>
                            

                            <form action="" method="post" style="display: inline-block;">
                                <input type="hidden" name="id" value="<?php echo $author['Author_ID']; ?>">
                                <button type="submit" name="delete_author">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
                </div>

    </main>
    <footer class="footer">
 
    </footer>

</body>
</html>
